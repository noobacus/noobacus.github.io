Hello, I am Vuong Ngo.
Welcome to my interactive CV.
To view it, open the executable application. Alternatively, you can open the jar file if you wish.